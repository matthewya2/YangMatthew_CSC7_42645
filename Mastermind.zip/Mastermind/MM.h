/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MM.h
 * Author: rcc
 *
 * Created on April 6, 2017, 1:57 PM
 */

#ifndef MM_H
#define MM_H

class MM{
    private:
        
    public:
        int Rand(){
            return rand()%10;   
        };
};

#endif /* MM_H */

